# RollABallUnity
Tutorial Unity project RollABall from tutorial https://learn.unity.com/project/roll-a-ball

To win you need to collect all 7 yellow cubes and not get eaten by the red enemmy chasing you.
the green cubes can be moved by colliding with them
You can play tthe game by opening the minigame scene in Unity or running the .exe file in the zip folder

Created by Martin Letenay
27th September 2024

in case of problems contact me by email
letenay7@uniba.sk

